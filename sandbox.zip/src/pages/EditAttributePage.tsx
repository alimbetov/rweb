// src/pages/EditAttributePage.tsx
import React, { useEffect, useState } from "react";
import { Attribute } from "../types/types";
import { getAttributeByCode, updateAttribute } from "../apidata/attributeApi";

import { useNavigate, useParams } from "react-router-dom";

const EditAttributePage: React.FC = () => {
  const { code } = useParams<{ code: string }>();
  const navigate = useNavigate();
  const [attribute, setAttribute] = useState<Attribute | null>(null);

  useEffect(() => {
    if (code) {
      getAttributeByCode(code).then(setAttribute);
    }
  }, [code]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setAttribute((prev) => (prev ? { ...prev, [name]: value } : null));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (attribute) {
      await updateAttribute(code!, attribute);
      navigate("/attributes");
    }
  };

  if (!attribute) return <div>Загрузка...</div>;

  return (
    <div>
      <h2>Редактировать атрибут</h2>
      <form onSubmit={handleSubmit}>
        <input name="nameRu" value={attribute.nameRu} onChange={handleChange} />
        <input name="nameKz" value={attribute.nameKz} onChange={handleChange} />
        <input name="nameEn" value={attribute.nameEn} onChange={handleChange} />
        <button type="submit">Сохранить</button>
      </form>
    </div>
  );
};

export default EditAttributePage;
